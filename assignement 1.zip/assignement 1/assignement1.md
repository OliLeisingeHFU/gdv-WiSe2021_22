Die optische Illusion zeigt die unterschiedliche Wahrnehmung eines Grautones, abhängig vom Hintergrund.
Zu sehen sind zwei Quadrate, einmal auf hellerem, einmal auf dunklerem Hintergrund. Schwer zu erkennen ist, dass beide Quadrate eine Kopie aus der Mitte sind und den exakt gleichen Grauton bzw Grauverlauf zeigen.

Wird der Code gestartet, wird erst ein 1 Pixel Hohes, 255 Pixel Weites Bild. Dieses ist erst komplett schwarz. Dann wird über eine for-Schleife der Gradient erstellt. Damit man auch was erkennen kann wird es auf 200px Höhe und 765px Weite gestreckt.
Aus der Mitte wird eine Box kopiert und jeweils am dunklen und am hellen Ende eingefügt. Zuletzt wird das Bild im aktuellen Ordner gespeichert und in einem neuen Fenster angezeigt.