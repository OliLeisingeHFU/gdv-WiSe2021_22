To use the Application, simply extract all files from the ZIP-file and open the Folder in Visual Studio Code.

To run assignement3.py, Python 3.9.7 as well as OpenCV 4.5 are required.

You can find all images in the image-folger. 

To get the Lowpass-filter from the first image a black Cercle added to the mid of the Frequencies removes the high frequences and "blurs" the image.

To get the edges in the second image, anything else than a midcercle gets black to remove the low frequencies in the second image.

From close up the first image shows a man, with more distance it looks like a woman.
The second image shows a child if you look without distance and a woman from further away.


Change image_name_lpf_1  to  image_name_lpf_2  and  image_name_hpf_1  to  image_name_hpf_2 to load the second result.

Close the Windows with 'q'

